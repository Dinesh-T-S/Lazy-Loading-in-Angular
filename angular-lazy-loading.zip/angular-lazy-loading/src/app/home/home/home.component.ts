import { Component } from '@angular/core';

console.log("Home loaded Successfully")

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

}
